package application;

public class Listed {
	
	// 입력된 게 todo에 저장되서 
	private String todo = "유도가기";

	public Listed(String insert) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "⬜ " + todo;
	}

	public void add(Listed listed) {
		// TODO Auto-generated method stub
		
	}
}
