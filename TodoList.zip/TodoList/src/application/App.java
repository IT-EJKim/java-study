package application;

public class App {
	public static void main(String[] args) {
		TodoList tl = new TodoList();
		tl.run();
	}
}
